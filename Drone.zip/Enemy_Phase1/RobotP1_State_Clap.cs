using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotP1_State_Clap : Robot_State<Robot_P1>
{
    public void OnEnter(Robot_P1 robot_p1)
    {

    }

    public void OnUpdate(Robot_P1 robot_p1)
    {


    }

    public void OnExit(Robot_P1 robot_p1)
    {

    }

    public void OnFixedUpdate(Robot_P1 robot_p1)
    {

    }
}
