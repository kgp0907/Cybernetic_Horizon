using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class State_Heal : DState<Drone>
{
    public void OnEnter(Drone drone)
    {

    }

    public void OnUpdate(Drone drone)
    {

    }

    public void OnExit(Drone drone)
    {

    }

    public void OnFixedUpdate(Drone drone)
    {

    }
}
